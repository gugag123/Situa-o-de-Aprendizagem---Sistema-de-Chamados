package br.com.equipe3.chamados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ChamadosApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChamadosApplication.class, args);
    }
}
